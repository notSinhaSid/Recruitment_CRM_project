<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Role;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $roles = [
            ['name'=> 'Admin', 'display_name' => 'Administrator'],
            ['name'=> 'Recruiter', 'display_name' => 'Recruiter'],
            ['name'=> 'Hiring Manager', 'display_name' => 'Hiring Manager'],
            ['name'=> 'Super Admin', 'display_name' => 'Super Admin'],
        ];

        foreach($roles as $role) {
            Role::firstOrCreate(['name' => $role['name']],
                                ['display_name' => $role['display_name']]);
        }
    }
}
